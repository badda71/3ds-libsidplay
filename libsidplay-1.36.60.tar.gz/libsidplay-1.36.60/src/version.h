//
// /home/ms/source/sidplay/libsidplay/include/RCS/version.h,v
//

#ifndef SIDPLAY1_VERSION_H
#define SIDPLAY1_VERSION_H


#define emu_version "1.36.59"


#endif  /* SIDPLAY1_VERSION_H */
