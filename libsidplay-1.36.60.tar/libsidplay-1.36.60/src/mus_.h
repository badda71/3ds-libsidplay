//
// /home/ms/source/sidplay/libsidplay/fformat/RCS/mus_.h,v
//

#ifndef SIDPLAY1_MUS__H
#define SIDPLAY1_MUS__H


#include "compconf.h"
#include "mytypes.h"
#include "myendian.h"
#include "smart.h"
#include "sidtune.h"


#endif  /* SIDPLAY1_MUS__H */
